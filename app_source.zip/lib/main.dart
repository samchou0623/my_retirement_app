import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

String _dateKey(DateTime date) =>
    '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

String _monthKey(DateTime date) =>
    '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}';

String _displayDate(DateTime date) => '${date.year}/${date.month}/${date.day}';

class SavingsRecord {
  final int? id;
  final DateTime date;
  final double amount;

  const SavingsRecord({this.id, required this.date, required this.amount});

  factory SavingsRecord.fromMap(Map<String, Object?> map) => SavingsRecord(
        id: map['id'] as int?,
        date: DateTime.parse(map['date'] as String),
        amount: (map['amount'] as num).toDouble(),
      );
}

class MemoRecord {
  final int? id;
  final DateTime date;
  final String content;

  const MemoRecord({this.id, required this.date, required this.content});

  factory MemoRecord.fromMap(Map<String, Object?> map) => MemoRecord(
        id: map['id'] as int?,
        date: DateTime.parse(map['date'] as String),
        content: map['content'] as String,
      );
}

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final databasePath = await getDatabasesPath();
    _database = await openDatabase(
      p.join(databasePath, 'retirement_records.db'),
      version: 1,
      onCreate: (database, version) async {
        await database.execute('''
          CREATE TABLE savings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL UNIQUE,
            amount REAL NOT NULL
          )
        ''');
        await database.execute('''
          CREATE TABLE memos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            content TEXT NOT NULL
          )
        ''');
      },
    );
    return _database!;
  }

  Future<List<SavingsRecord>> getSavings() async {
    final rows = await (await database).query('savings', orderBy: 'date ASC');
    return rows.map(SavingsRecord.fromMap).toList();
  }

  Future<void> saveSavings(DateTime date, double amount) async {
    await (await database).insert(
      'savings',
      {'date': _dateKey(date), 'amount': amount},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<MemoRecord>> getMemos(DateTime month) async {
    final rows = await (await database).query(
      'memos',
      where: 'date LIKE ?',
      whereArgs: ['${_monthKey(month)}%'],
      orderBy: 'date DESC, id DESC',
    );
    return rows.map(MemoRecord.fromMap).toList();
  }

  Future<void> saveMemo({int? id, required DateTime date, required String content}) async {
    final db = await database;
    final values = {'date': _dateKey(date), 'content': content};
    if (id == null) {
      await db.insert('memos', values);
    } else {
      await db.update('memos', values, where: 'id = ?', whereArgs: [id]);
    }
  }

  Future<void> deleteMemo(int id) async {
    await (await database).delete('memos', where: 'id = ?', whereArgs: [id]);
  }
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  if (defaultTargetPlatform == TargetPlatform.windows ||
      defaultTargetPlatform == TargetPlatform.linux ||
      defaultTargetPlatform == TargetPlatform.macOS) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  }
  runApp(const RetirementApp());
}

class RetirementApp extends StatelessWidget {
  const RetirementApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '退休倒數計時器',
      theme: ThemeData(primarySwatch: Colors.teal, useMaterial3: true),
      home: const InitialCheckScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class InitialCheckScreen extends StatefulWidget {
  const InitialCheckScreen({super.key});
  @override
  State<InitialCheckScreen> createState() => _InitialCheckScreenState();
}

class _InitialCheckScreenState extends State<InitialCheckScreen> {
  bool _isLoading = true;
  String? _savedBirthdate;

  @override
  void initState() {
    super.initState();
    _checkSavedData();
  }

  Future<void> _checkSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _savedBirthdate = prefs.getString('birthdate');
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return _savedBirthdate != null 
        ? DashboardScreen(birthdateStr: _savedBirthdate!) 
        : SetupScreen(onSetupComplete: (newDate) => setState(() => _savedBirthdate = newDate));
  }
}
class SetupScreen extends StatefulWidget {
  final Function(String) onSetupComplete;
  const SetupScreen({super.key, required this.onSetupComplete});
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  DateTime? _selectedDate, _retirementDate;
  bool _isSaving = false;

  Future<void> _pickDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime(1990, 1, 1),
      firstDate: DateTime(1940, 1, 1),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
        _retirementDate = DateTime(picked.year + 60, picked.month, picked.day);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('歡迎使用退休倒數')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('開創您的理財與悠閒生活，系統將為您即時追蹤重要的退休里程碑！', textAlign: TextAlign.center, style: TextStyle(fontSize: 16, color: Colors.grey)),
            const SizedBox(height: 40),
            ElevatedButton.icon(
              icon: const Icon(Icons.calendar_today),
              label: Text(_selectedDate == null ? '請選擇您的出生年月日' : '生日：${_selectedDate!.year}年${_selectedDate!.month}月${_selectedDate!.day}日', style: const TextStyle(fontSize: 18)),
              onPressed: () => _pickDate(context),
            ),
            if (_retirementDate != null) ...[
              const SizedBox(height: 30),
              Card(
                color: Colors.teal.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text('預計滿 60 歲日期：\n${_retirementDate!.year} 年 ${_retirementDate!.month} 月 ${_retirementDate!.day} 日', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal.shade900)),
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white),
                onPressed: _isSaving
                    ? null
                    : () async {
                        final selectedDate = _selectedDate;
                        if (selectedDate == null) return;
                        setState(() => _isSaving = true);
                        try {
                          final birthdate = selectedDate.toIso8601String();
                          final prefs = await SharedPreferences.getInstance();
                          await prefs.setString('birthdate', birthdate);
                          if (!mounted) return;
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (_) => DashboardScreen(birthdateStr: birthdate)),
                          );
                        } catch (error) {
                          if (!mounted) return;
                          setState(() => _isSaving = false);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('無法儲存生日資料：$error')),
                          );
                        }
                      },
                child: Text(_isSaving ? '正在開啟...' : '開啟我的退休倒數', style: const TextStyle(fontSize: 18)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  final String birthdateStr;
  const DashboardScreen({super.key, required this.birthdateStr});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}
class _DashboardScreenState extends State<DashboardScreen> {
  final List<String> _quotes = [
    "✨ 努力投資，不要亂賣股票！",
    "☕ 低點時，千萬不要賣股票，反而要設法買進！",
    "🌱 市場一直都在，如果沒有好時機，寧願留著現金！",
    "🚲 堅持，才能期待100萬變成1000萬的驚喜！",
    "📅 必須把精力集中在減少損失，利潤自然會增長！"
  ];
  late String _currentQuote;
  double _currentSavings = 0, _targetSavings = 1000000;
  List<String> _userQuotes = [];
  List<SavingsRecord> _savingsRecords = [];
  List<MemoRecord> _memos = [];
  DateTime _selectedMonth = DateTime(DateTime.now().year, DateTime.now().month);

  @override
  void initState() {
    super.initState();
    _currentQuote = "✨ 點擊卡片，抽取今日理財智慧！";
    _loadRecords();
    _loadQuotesData();
  }

  String _formatMoney(double amount) {
    RegExp reg = RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))');
    return amount.toStringAsFixed(0).replaceAllMapped(reg, (Match m) => '${m.group(1)},');
  }

  Future<void> _loadQuotesData() async {
    final prefs = await SharedPreferences.getInstance();
    List<String>? saved = prefs.getStringList('customQuotes');
    setState(() {
      _userQuotes = (saved == null || saved.isEmpty) ? List.from(_quotes) : saved;
      _randomQuote();
    });
  }

  void _randomQuote() {
    if (_userQuotes.isEmpty) {
      setState(() => _currentQuote = "📌 目前籤筒空空如也，快去新增勵志語吧！");
    } else {
      setState(() => _currentQuote = _userQuotes[Random().nextInt(_userQuotes.length)]);
    }
  }

  Future<void> _loadRecords() async {
    final database = AppDatabase.instance;
    final prefs = await SharedPreferences.getInstance();
    var records = await database.getSavings();
    if (records.isEmpty && prefs.containsKey('currentSavings')) {
      await database.saveSavings(DateTime.now(), prefs.getDouble('currentSavings') ?? 0);
      records = await database.getSavings();
    }
    final target = prefs.getDouble('targetSavings') ?? 1000000;
    if (!mounted) return;
    setState(() {
      _savingsRecords = records;
      _currentSavings = records.isEmpty ? 0 : records.last.amount;
      _targetSavings = target;
    });
    await _loadMemos();
  }

  Future<void> _loadMemos() async {
    final memos = await AppDatabase.instance.getMemos(_selectedMonth);
    if (mounted) setState(() => _memos = memos);
  }

  void _selectMonth(DateTime month) {
    setState(() => _selectedMonth = month);
    _loadMemos();
  }

  Future<void> _pickDate(BuildContext dialogContext, DateTime initialDate, ValueChanged<DateTime> onPicked) async {
    final picked = await showDatePicker(
      context: dialogContext,
      initialDate: initialDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (picked != null) onPicked(picked);
  }

  void _showQuotesManagementDialog() {
    final addController = TextEditingController();
    int? editingIndex;
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('🛠️ 自由新增/修改理財語'),
          content: SizedBox(
            width: double.maxFinite,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: addController, decoration: const InputDecoration(labelText: '輸入新的理財勵志語')),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () async {
                    if (addController.text.trim().isEmpty) return;
                    final quote = addController.text.trim();
                    if (editingIndex == null) {
                      _userQuotes.add(quote);
                    } else {
                      _userQuotes[editingIndex!] = quote;
                    }
                    await (await SharedPreferences.getInstance()).setStringList('customQuotes', _userQuotes);
                    addController.clear();
                    editingIndex = null;
                    setDialogState(() {});
                    setState(() {});
                  },
                  child: Text(editingIndex == null ? '新增一筆提示' : '儲存修改'),
                ),
                const Divider(height: 20),
                Expanded(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: _userQuotes.length,
                    itemBuilder: (context, idx) => ListTile(
                      title: Text(_userQuotes[idx], style: const TextStyle(fontSize: 13)),
                      onTap: () {
                        addController.text = _userQuotes[idx];
                        addController.selection = TextSelection.collapsed(offset: addController.text.length);
                        editingIndex = idx;
                        setDialogState(() {});
                      },
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                        onPressed: () async {
                          _userQuotes.removeAt(idx);
                          await (await SharedPreferences.getInstance()).setStringList('customQuotes', _userQuotes);
                          setDialogState(() {});
                          setState(() {});
                        },
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [TextButton(onPressed: () { _randomQuote(); Navigator.pop(context); }, child: const Text('完成離開'))],
        ),
      ),
    );
  }

  void _showSettingsDialog() {
    DateTime selectedDate = DateTime.now();
    final currentController = TextEditingController(text: _currentSavings.toStringAsFixed(0));
    final targetController = TextEditingController(text: _targetSavings.toStringAsFixed(0));
    showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
        title: const Text('記錄每日儲蓄'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.event, color: Colors.teal),
              title: const Text('記錄日期'),
              subtitle: Text(_displayDate(selectedDate)),
              onTap: () => _pickDate(dialogContext, selectedDate, (date) => setDialogState(() => selectedDate = date)),
            ),
            TextField(controller: currentController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '當日已儲蓄金額 (元)')),
            TextField(controller: targetController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '總退休目標金額 (元)')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
          ElevatedButton(
            onPressed: () async {
              final c = double.tryParse(currentController.text) ?? 0;
              final t = double.tryParse(targetController.text) ?? 1000000;
              final double validTarget = t > 0 ? t : 1000000;
              final prefs = await SharedPreferences.getInstance();
              await prefs.setDouble('currentSavings', c);
              await prefs.setDouble('targetSavings', validTarget);
              await AppDatabase.instance.saveSavings(selectedDate, c);
              await _loadRecords();
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('儲存'),
          ),
        ],
      ),),
    );
  }

  Widget _buildSavingsTrend() {
    final byMonth = <String, SavingsRecord>{};
    for (final record in _savingsRecords) {
      byMonth[_monthKey(record.date)] = record;
    }
    final points = byMonth.values.toList()..sort((a, b) => a.date.compareTo(b.date));
    final maxAmount = points.fold<double>(_targetSavings, (max, record) => record.amount > max ? record.amount : max);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('儲蓄趨勢', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.teal)),
            Row(
              children: [
                IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => _selectMonth(DateTime(_selectedMonth.year, _selectedMonth.month - 1))),
                Text('${_selectedMonth.year}/${_selectedMonth.month}', style: const TextStyle(fontWeight: FontWeight.bold)),
                IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => _selectMonth(DateTime(_selectedMonth.year, _selectedMonth.month + 1))),
              ],
            ),
          ],
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 150,
          child: points.isEmpty
              ? const Center(child: Text('這個月還沒有儲蓄紀錄', style: TextStyle(color: Colors.black45)))
              : LayoutBuilder(
                  builder: (context, constraints) => GestureDetector(
                    onTapUp: (details) {
                      final index = (details.localPosition.dx / (constraints.maxWidth / points.length)).floor().clamp(0, points.length - 1);
                      final record = points[index];
                      _selectMonth(DateTime(record.date.year, record.date.month));
                    },
                    child: CustomPaint(
                      size: Size.infinite,
                      painter: _SavingsChartPainter(points: points, maxAmount: maxAmount),
                    ),
                  ),
                ),
        ),
        if (points.isNotEmpty) const Text('點擊任一月份查看當月備忘錄', style: TextStyle(fontSize: 11, color: Colors.black45)),
      ],
    );
  }

  void _showMemoDialog({MemoRecord? memo}) {
    DateTime selectedDate = memo?.date ?? DateTime.now();
    final controller = TextEditingController(text: memo?.content ?? '');
    showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(memo == null ? '新增備忘錄' : '編輯備忘錄'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.event_note, color: Colors.teal),
                title: const Text('記錄日期'),
                subtitle: Text(_displayDate(selectedDate)),
                onTap: () => _pickDate(dialogContext, selectedDate, (date) => setDialogState(() => selectedDate = date)),
              ),
              TextField(controller: controller, maxLines: 4, decoration: const InputDecoration(hintText: '寫下今天的心情或理財筆記')),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('取消')),
            ElevatedButton(
              onPressed: () async {
                if (controller.text.trim().isEmpty) return;
                await AppDatabase.instance.saveMemo(id: memo?.id, date: selectedDate, content: controller.text.trim());
                if (!mounted) return;
                Navigator.pop(dialogContext);
                await _loadMemos();
              },
              child: const Text('儲存'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMemoHistory() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('${_selectedMonth.year}/${_selectedMonth.month} 的備忘錄', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.teal)),
            IconButton(icon: const Icon(Icons.add_circle, color: Colors.teal), tooltip: '新增備忘錄', onPressed: () => _showMemoDialog()),
          ],
        ),
        if (_memos.isEmpty)
          const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('尚無文字記錄，寫下今天的心情吧。', style: TextStyle(color: Colors.black45)))
        else
          ..._memos.map(
            (memo) => ListTile(
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(backgroundColor: Colors.teal.shade50, child: Text('${memo.date.day}', style: const TextStyle(color: Colors.teal))),
              title: Text(memo.content),
              subtitle: Text(_displayDate(memo.date)),
              onTap: () => _showMemoDialog(memo: memo),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                onPressed: () async {
                  await AppDatabase.instance.deleteMemo(memo.id!);
                  await _loadMemos();
                },
              ),
            ),
          ),
      ],
    );
  }

  Map<String, int> _calculateRemainingTime(DateTime retirement) {
    DateTime now = DateTime.now();
    if (now.isAfter(retirement)) return {'years': 0, 'months': 0, 'days': 0};
    int years = retirement.year - now.year, months = retirement.month - now.month, days = retirement.day - now.day;
    if (days < 0) { days += DateTime(now.year, now.month, 0).day; months--; }
    if (months < 0) { months += 12; years--; }
    return {'years': years, 'months': months, 'days': days};
  }

  Widget _buildTimeUnit(String value, String unit) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      children: [
        Text(value, style: const TextStyle(fontSize: 42, fontWeight: FontWeight.bold, color: Colors.deepOrange)),
        Text(' $unit ', style: const TextStyle(fontSize: 18, color: Colors.black54, fontWeight: FontWeight.bold)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final birthdate = DateTime.parse(widget.birthdateStr);
    final retirementDate = DateTime(birthdate.year + 60, birthdate.month, birthdate.day);
    final remaining = _calculateRemainingTime(retirementDate);
    double progress = _currentSavings / _targetSavings;
    if (progress > 1.0) progress = 1.0;
    if (progress < 0.0) progress = 0.0;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.teal.shade800, Colors.teal.shade50])),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 40),
                  const Text('⏳ 距離您的悠閒生活還有...', style: TextStyle(fontSize: 20, color: Colors.white70, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 5))]),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      textBaseline: TextBaseline.alphabetic,
                      children: [
                        _buildTimeUnit(remaining['years']!.toString(), '年'),
                        _buildTimeUnit(remaining['months']!.toString(), '個月'),
                        _buildTimeUnit(remaining['days']!.toString(), '日'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text('將於 ${retirementDate.year} 年 ${retirementDate.month} 月 ${retirementDate.day} 日滿 60 歲', style: TextStyle(fontSize: 16, color: Colors.black.withOpacity(0.8), fontWeight: FontWeight.bold)),
                  const SizedBox(height: 30),
                  GestureDetector(
                    onTap: _showSettingsDialog,
                    child: Card(
                      elevation: 4,
                      color: Colors.white.withOpacity(0.95),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Row(children: [Icon(Icons.account_balance_wallet, color: Colors.teal), Text(' 退休金存錢進度', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.teal))]),
                                Text('${(progress * 100).toStringAsFixed(1)} %', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.deepOrange)),
                              ],
                            ),
                            const SizedBox(height: 15),
                            ClipRRect(borderRadius: BorderRadius.circular(10), child: LinearProgressIndicator(value: progress, minHeight: 12, backgroundColor: Colors.grey.shade300, valueColor: const AlwaysStoppedAnimation<Color>(Colors.deepOrange))),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text('已存: \$${_formatMoney(_currentSavings)}', style: const TextStyle(fontSize: 13, color: Colors.black54, fontWeight: FontWeight.bold)),
                                Text('目標: \$${_formatMoney(_targetSavings)}', style: const TextStyle(fontSize: 13, color: Colors.black54, fontWeight: FontWeight.bold)),
                              ],
                            ),
                            const Divider(height: 20),
                            const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.edit, size: 14, color: Colors.black38), Text(' 點擊卡片更新儲蓄進度', style: TextStyle(fontSize: 12, color: Colors.black38))]),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Card(
                    elevation: 3,
                    color: Colors.white.withOpacity(0.95),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(children: [_buildSavingsTrend(), const Divider(height: 28), _buildMemoHistory()]),
                    ),
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: _randomQuote,
                    child: Card(
                      elevation: 4,
                      color: Colors.white.withOpacity(0.95),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Column(
                          children: [
                            Text(_currentQuote, textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: Colors.teal, fontStyle: FontStyle.italic, height: 1.5)),
                            const SizedBox(height: 15),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                TextButton.icon(icon: const Icon(Icons.settings, size: 16, color: Colors.teal), label: const Text('🛠️ 管理自訂金句', style: TextStyle(fontSize: 12, color: Colors.teal)), onPressed: _showQuotesManagementDialog),
                                const Row(children: [Icon(Icons.touch_app, size: 16, color: Colors.black38), Text(' 隨機抽籤', style: TextStyle(fontSize: 12, color: Colors.black38))]),
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                  TextButton.icon(
                    icon: const Icon(Icons.refresh, color: Colors.black54),
                    label: const Text('重設生日', style: TextStyle(color: Colors.black54)),
                    onPressed: () async {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.remove('birthdate');
                      if (!context.mounted) return;
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const InitialCheckScreen()));
                    },
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _SavingsChartPainter extends CustomPainter {
  final List<SavingsRecord> points;
  final double maxAmount;

  const _SavingsChartPainter({required this.points, required this.maxAmount});

  @override
  void paint(Canvas canvas, Size size) {
    final chartHeight = size.height - 24;
    final chartWidth = size.width;
    final linePaint = Paint()
      ..color = Colors.teal
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final fillPaint = Paint()
      ..color = Colors.teal.withOpacity(0.12)
      ..style = PaintingStyle.fill;
    final axisPaint = Paint()
      ..color = Colors.black12
      ..strokeWidth = 1;

    canvas.drawLine(Offset(0, chartHeight), Offset(chartWidth, chartHeight), axisPaint);
    if (points.isEmpty || maxAmount <= 0) return;
    final path = Path();
    final fillPath = Path()..moveTo(0, chartHeight);
    for (var index = 0; index < points.length; index++) {
      final x = points.length == 1 ? chartWidth / 2 : chartWidth * index / (points.length - 1);
      final y = chartHeight - (points[index].amount / maxAmount * (chartHeight - 12));
      final point = Offset(x, y);
      if (index == 0) {
        path.moveTo(x, y);
        fillPath.lineTo(x, y);
      } else {
        path.lineTo(x, y);
        fillPath.lineTo(x, y);
      }
      canvas.drawCircle(point, 4, Paint()..color = Colors.deepOrange);
    }
    fillPath.lineTo(chartWidth, chartHeight);
    fillPath.close();
    canvas.drawPath(fillPath, fillPaint);
    canvas.drawPath(path, linePaint);
    final textPainter = TextPainter(textDirection: TextDirection.ltr);
    for (final point in points) {
      final x = points.length == 1 ? chartWidth / 2 : chartWidth * points.indexOf(point) / (points.length - 1);
      textPainter.text = TextSpan(text: '${point.date.month}月', style: const TextStyle(fontSize: 10, color: Colors.black45));
      textPainter.layout();
      textPainter.paint(canvas, Offset(x - textPainter.width / 2, chartHeight + 4));
    }
  }

  @override
  bool shouldRepaint(covariant _SavingsChartPainter oldDelegate) => oldDelegate.points != points || oldDelegate.maxAmount != maxAmount;
}
