import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const RetirementApp());
}

class RetirementApp extends StatelessWidget {
  const RetirementApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '退休倒數計時器',
      theme: ThemeData(
        primarySwatch: Colors.teal,
        useMaterial3: true,
      ),
      home: const InitialCheckScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class InitialCheckScreen extends StatefulWidget {
  const InitialCheckScreen({super.key});

  @override
  State<InitialCheckScreen> createState() => _InitialCheckScreenState();
}

class _InitialCheckScreenState extends State<InitialCheckScreen> {
  bool _isLoading = true;
  String? _savedBirthdate;

  @override
  void initState() {
    super.initState();
    _checkSavedData();
  }

  Future<void> _checkSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _savedBirthdate = prefs.getString('birthdate');
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    
    if (_savedBirthdate != null) {
      return DashboardScreen(birthdateStr: _savedBirthdate!);
    } else {
      return SetupScreen(onSetupComplete: (newDate) {
        setState(() {
          _savedBirthdate = newDate;
        });
      });
    }
  }
}

class SetupScreen extends StatefulWidget {
  final Function(String) onSetupComplete;
  const SetupScreen({super.key, required this.onSetupComplete});

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  DateTime? _selectedDate;
  DateTime? _retirementDate;

  Future<void> _pickDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime(1990, 1, 1),
      firstDate: DateTime(1940, 1, 1),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
        _retirementDate = DateTime(picked.year + 60, picked.month, picked.day);
      });
    }
  }

  Future<void> _saveAndProceed() async {
    if (_selectedDate == null) return;
    final prefs = await SharedPreferences.getInstance();
    String dateStr = _selectedDate!.toIso8601String();
    await prefs.setString('birthdate', dateStr);
    
    if (!mounted) return;
    widget.onSetupComplete(dateStr);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('歡迎使用退休倒數')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              '只要設定一次生日，系統將為您即時追蹤重要的退休里程碑！',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
            const SizedBox(height: 40),
            ElevatedButton.icon(
              icon: const Icon(Icons.calendar_today),
              label: Text(
                _selectedDate == null
                    ? '請選擇您的出生年月日'
                    : '生日：${_selectedDate!.year}年${_selectedDate!.month}月${_selectedDate!.day}日',
                style: const TextStyle(fontSize: 18),
              ),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16), // 🌟 這裡修正為正確的 .symmetric 語法
              ),
              onPressed: () => _pickDate(context),
            ),
            const SizedBox(height: 30),
            if (_retirementDate != null) ...[
              Card(
                color: Colors.teal.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    '預計滿 60 歲日期：\n${_retirementDate!.year} 年 ${_retirementDate!.month} 月 ${_retirementDate!.day} 日',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal.shade900),
                  ),
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16), // 🌟 這裡也一併修正完成
                ),
                onPressed: _saveAndProceed,
                child: const Text('開啟我的退休倒數', style: TextStyle(fontSize: 18)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class DashboardScreen extends StatelessWidget {
  final String birthdateStr;
  const DashboardScreen({super.key, required this.birthdateStr});

  Map<String, int> _calculateRemainingTime(DateTime retirement) {
    DateTime now = DateTime.now();
    if (now.isAfter(retirement)) {
      return {'years': 0, 'months': 0, 'days': 0};
    }

    int years = retirement.year - now.year;
    int months = retirement.month - now.month;
    int days = retirement.day - now.day;

    if (days < 0) {
      final previousMonth = DateTime(now.year, now.month, 0);
      days += previousMonth.day;
      months--;
    }
    if (months < 0) {
      months += 12;
      years--;
    }

    return {'years': years, 'months': months, 'days': days};
  }

  @override
  Widget build(BuildContext context) {
    final birthdate = DateTime.parse(birthdateStr);
    final retirementDate = DateTime(birthdate.year + 60, birthdate.month, birthdate.day);
    final remaining = _calculateRemainingTime(retirementDate);

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.teal.shade800, Colors.teal.shade50],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  '⏳ 距離您的悠閒生活還有...',
                  style: TextStyle(fontSize: 20, color: Colors.white70, fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 5))],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      _buildTimeUnit(remaining['years']!.toString(), '年'),
                      _buildTimeUnit(remaining['months']!.toString(), '個月'),
                      _buildTimeUnit(remaining['days']!.toString(), '日'),
                    ],
                  ),
                ),
                const SizedBox(height: 40),
                Text(
                  '將於 ${retirementDate.year} 年 ${retirementDate.month} 月 ${retirementDate.day} 日滿 60 歲',
                  style: TextStyle(fontSize: 16, color: Colors.black.withValues(alpha: 0.8), fontWeight: FontWeight.bold), // 🌟 這裡也更新為最新的 .withValues 語法避免警告
                ),
                const SizedBox(height: 60),
                TextButton.icon(
                  icon: const Icon(Icons.refresh, color: Colors.black54),
                  label: const Text('重設生日', style: TextStyle(color: Colors.black54)),
                  onPressed: () async {
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.remove('birthdate');
                    
                    if (!context.mounted) return;
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => const InitialCheckScreen()),
                    );
                  },
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTimeUnit(String value, String unit) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      children: [
        Text(
          value,
          style: const TextStyle(fontSize: 42, fontWeight: FontWeight.bold, color: Colors.deepOrange),
        ),
        Text(
          ' $unit ',
          style: const TextStyle(fontSize: 18, color: Colors.black54, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
