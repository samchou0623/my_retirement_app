package com.example.app_retirement

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
