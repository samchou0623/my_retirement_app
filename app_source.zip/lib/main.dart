import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const RetirementApp());
}

class RetirementApp extends StatelessWidget {
  const RetirementApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '退休倒數計時器',
      theme: ThemeData(
        primarySwatch: Colors.teal,
        useMaterial3: true,
      ),
      home: const InitialCheckScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class InitialCheckScreen extends StatefulWidget {
  const InitialCheckScreen({super.key});

  @override
  State<InitialCheckScreen> createState() => _InitialCheckScreenState();
}

class _InitialCheckScreenState extends State<InitialCheckScreen> {
  bool _isLoading = true;
  String? _savedBirthdate;

  @override
  void initState() {
    super.initState();
    _checkSavedData();
  }

  Future<void> _checkSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _savedBirthdate = prefs.getString('birthdate');
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    
    if (_savedBirthdate != null) {
      return DashboardScreen(birthdateStr: _savedBirthdate!);
    } else {
      return SetupScreen(onSetupComplete: (newDate) {
        setState(() {
          _savedBirthdate = newDate;
        });
      });
    }
  }
}
class SetupScreen extends StatefulWidget {
  final Function(String) onSetupComplete;
  const SetupScreen({super.key, required this.onSetupComplete});

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  DateTime? _selectedDate;
  DateTime? _retirementDate;

  Future<void> _pickDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime(1990, 1, 1),
      firstDate: DateTime(1940, 1, 1),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
        _retirementDate = DateTime(picked.year + 60, picked.month, picked.day);
      });
    }
  }

  Future<void> _saveAndProceed() async {
    if (_selectedDate == null) return;
    final prefs = await SharedPreferences.getInstance();
    String dateStr = _selectedDate!.toIso8601String();
    await prefs.setString('birthdate', dateStr);
    
    if (!mounted) return;
    widget.onSetupComplete(dateStr);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('歡迎使用退休倒數')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              '開創您的理財與悠閒生活，系統將為您即時追蹤重要的退休里程碑！',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
            const SizedBox(height: 40),
            ElevatedButton.icon(
              icon: const Icon(Icons.calendar_today),
              label: Text(
                _selectedDate == null
                    ? '請選擇您的出生年月日'
                    : '生日：${_selectedDate!.year}年${_selectedDate!.month}月${_selectedDate!.day}日',
                style: const TextStyle(fontSize: 18),
              ),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              onPressed: () => _pickDate(context),
            ),
            const SizedBox(height: 30),
            if (_retirementDate != null) ...[
              Card(
                color: Colors.teal.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    '預計滿 60 歲日期：\n${_retirementDate!.year} 年 ${_retirementDate!.month} 月 ${_retirementDate!.day} 日',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal.shade900),
                  ),
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                onPressed: _saveAndProceed,
                child: const Text('開啟我的退休倒數', style: TextStyle(fontSize: 18)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
class DashboardScreen extends StatefulWidget {
  final String birthdateStr;
  const DashboardScreen({super.key, required this.birthdateStr});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final List<String> _quotes = [
    "✨ 努力投資，不要亂賣股票！",
    "☕ 低點時，千萬不要賣股票，反而要設法買進！",
    "🌱 市場一直都在，如果沒有好時機，寧願留著現金！",
    "🚲 堅持，才能期待100萬變成1000萬的驚喜！",
    "📅 找到適合自己的投資方式，讓利潤自然增長！"
  ];

  late String _currentQuote;
  double _currentSavings = 0;
  double _targetSavings = 1000000;

  @override
  void initState() {
    super.initState();
    _currentQuote = _quotes[Random().nextInt(_quotes.length)];
    _loadSavingsData();
  }

  String _formatMoney(double amount) {
    RegExp reg = RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))');
    return amount.toStringAsFixed(0).replaceAllMapped(reg, (Match match) => '${match},');
  }

  Future<void> _loadSavingsData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _currentSavings = prefs.getDouble('currentSavings') ?? 0;
      _targetSavings = prefs.getDouble('targetSavings') ?? 1000000;
    });
  }

  Future<void> _saveSavingsData(double current, double target) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('currentSavings', current);
    await prefs.setDouble('targetSavings', target);
    setState(() {
      _currentSavings = current;
      _targetSavings = target;
    });
  }

  void _changeQuote() {
    setState(() {
      _currentQuote = _quotes[Random().nextInt(_quotes.length)];
    });
  }

  void _showSettingsDialog() {
    final currentController = TextEditingController(text: _currentSavings.toStringAsFixed(0));
    final targetController = TextEditingController(text: _targetSavings.toStringAsFixed(0));

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('更新退休金目標'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: currentController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: '目前已儲蓄金額 (元)'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: targetController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: '總退休目標金額 (元)'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          ElevatedButton(
            onPressed: () {
              final current = double.tryParse(currentController.text) ?? 0;
              final target = double.tryParse(targetController.text) ?? 1000000;
              _saveSavingsData(current, target > 0 ? target : 1000000);
              Navigator.pop(context);
            },
            child: const Text('儲存'),
          ),
        ],
      ),
    );
  }

  Map<String, int> _calculateRemainingTime(DateTime retirement) {
    DateTime now = DateTime.now();
    if (now.isAfter(retirement)) {
      return {'years': 0, 'months': 0, 'days': 0};
    }

    int years = retirement.year - now.year;
    int months = retirement.month - now.month;
    int days = retirement.day - now.day;

    if (days < 0) {
      final previousMonth = DateTime(now.year, now.month, 0);
      days += previousMonth.day;
      months--;
    }
    if (months < 0) {
      months += 12;
      years--;
    }

    return {'years': years, 'months': months, 'days': days};
  }
  @override
  Widget build(BuildContext context) {
    final birthdate = DateTime.parse(widget.birthdateStr);
    final retirementDate = DateTime(birthdate.year + 60, birthdate.month, birthdate.day);
    final remaining = _calculateRemainingTime(retirementDate);

    double progress = _currentSavings / _targetSavings;
    if (progress > 1.0) progress = 1.0;
    if (progress < 0.0) progress = 0.0;
    double percentage = progress * 100;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.teal.shade800, Colors.teal.shade50],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 40),
                  const Text(
                    '⏳ 距離您的悠閒生活還有...',
                    style: TextStyle(fontSize: 20, color: Colors.white70, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 5))],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      textBaseline: TextBaseline.alphabetic,
                      children: [
                        _buildTimeUnit(remaining['years']!.toString(), '年'),
                        _buildTimeUnit(remaining['months']!.toString(), '個月'),
                        _buildTimeUnit(remaining['days']!.toString(), '日'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    '將於 ${retirementDate.year} 年 ${retirementDate.month} 月 ${retirementDate.day} 日滿 60 歲',
                    style: TextStyle(fontSize: 16, color: Colors.black.withOpacity(0.8), fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 30),

                  // 進度條卡片（🌟 已經把打錯字的那行徹底修正、對齊閉合囉！）
                  GestureDetector(
                    onTap: _showSettingsDialog,
                    child: Card(
                      elevation: 4,
                      color: Colors.white.withOpacity(0.95),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Row(
                                  children: [
                                    Icon(Icons.account_balance_wallet, color: Colors.teal),
                                    Text(' 退休金存錢進度', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.teal)),
                                  ],
                                ),
                                Text('${percentage.toStringAsFixed(1)} %', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.deepOrange)),
                              ],
                            ),
                            const SizedBox(height: 15),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: LinearProgressIndicator(
                                value: progress,
                                minHeight: 12,
                                backgroundColor: Colors.grey.shade300,
                                valueColor: const AlwaysStoppedAnimation<Color>(Colors.deepOrange),
                              ),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text('已存: \$${_formatMoney(_currentSavings)}', style: const TextStyle(fontSize: 13, color: Colors.black54, fontWeight: FontWeight.bold)),
                                Text('目標: \$${_formatMoney(_targetSavings)}', style: const TextStyle(fontSize: 13, color: Colors.black54, fontWeight: FontWeight.bold)),
                              ],
                            ),
                            const Divider(height: 20),
                            const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.edit, size: 14, color: Colors.black38),
                                Text(' 點擊卡片更新儲蓄進度', style: TextStyle(fontSize: 12, color: Colors.black38)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  
                  // 金句卡片
                  GestureDetector(
                    onTap: _changeQuote,
                    child: Card(
                      elevation: 4,
                      color: Colors.white.withOpacity(0.95),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Column(
                          children: [
                            Text(
                              _currentQuote,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w500,
                                color: Colors.teal,
                                fontStyle: FontStyle.italic,
                                height: 1.5,
                              ),
                            ),
                            const SizedBox(height: 10),
                            const Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Icon(Icons.touch_app, size: 16, color: Colors.black38),
                                Text(' 點擊換一句', style: TextStyle(fontSize: 12, color: Colors.black38)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 30),
                  TextButton.icon(
                    icon: const Icon(Icons.refresh, color: Colors.black54),
                    label: const Text('重設生日', style: TextStyle(color: Colors.black54)),
                    onPressed: () async {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.remove('birthdate');
                      
                      if (!context.mounted) return;
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => const InitialCheckScreen()),
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTimeUnit(String value, String unit) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      children: [
        Text(
          value,
          style: const TextStyle(fontSize: 42, fontWeight: FontWeight.bold, color: Colors.deepOrange),
        ),
        Text(
          ' $unit ',
          style: const TextStyle(fontSize: 18, color: Colors.black54, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
